--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = opcao_mpc, pg_catalog;

ALTER TABLE ONLY opcao_mpc.venda DROP CONSTRAINT venda_codigo_funcionario_fkey;
ALTER TABLE ONLY opcao_mpc.venda DROP CONSTRAINT venda_codigo_comissao_fkey;
ALTER TABLE ONLY opcao_mpc.venda DROP CONSTRAINT venda_codigo_cliente_fkey;
ALTER TABLE ONLY opcao_mpc.subproduto DROP CONSTRAINT subproduto_codigo_produto_fkey;
ALTER TABLE ONLY opcao_mpc.produtoestoque DROP CONSTRAINT produtoestoque_codigo_produto_fkey;
ALTER TABLE ONLY opcao_mpc.produtoestoque DROP CONSTRAINT produtoestoque_codigo_fornecedor_fkey;
ALTER TABLE ONLY opcao_mpc.itemvenda DROP CONSTRAINT itemvenda_codigo_venda_fkey;
ALTER TABLE ONLY opcao_mpc.itemvenda DROP CONSTRAINT itemvenda_codigo_subproduto_fkey;
ALTER TABLE ONLY opcao_mpc.itemvenda DROP CONSTRAINT itemvenda_codigo_produto_fkey;
ALTER TABLE ONLY opcao_mpc.compra DROP CONSTRAINT compra_codigo_produtoestoque_fkey;
ALTER TABLE ONLY opcao_mpc.comissao DROP CONSTRAINT comissao_codigo_funcionario_fkey;
DROP INDEX opcao_mpc.ix_usuario;
ALTER TABLE ONLY opcao_mpc.venda DROP CONSTRAINT venda_pkey;
ALTER TABLE ONLY opcao_mpc.super_usuario DROP CONSTRAINT super_usuario_pkey;
ALTER TABLE ONLY opcao_mpc.subproduto DROP CONSTRAINT subproduto_pkey;
ALTER TABLE ONLY opcao_mpc.produtoestoque DROP CONSTRAINT produtoestoque_pkey;
ALTER TABLE ONLY opcao_mpc.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY opcao_mpc.log DROP CONSTRAINT log_pkey;
ALTER TABLE ONLY opcao_mpc.itemvenda DROP CONSTRAINT itemvenda_pkey;
ALTER TABLE ONLY opcao_mpc.gastogenerico DROP CONSTRAINT gastogenerico_pkey;
ALTER TABLE ONLY opcao_mpc.funcionario DROP CONSTRAINT funcionario_pkey;
ALTER TABLE ONLY opcao_mpc.fornecedor DROP CONSTRAINT fornecedor_pkey;
ALTER TABLE ONLY opcao_mpc.compra DROP CONSTRAINT compra_pkey;
ALTER TABLE ONLY opcao_mpc.comissao DROP CONSTRAINT comissao_pkey;
ALTER TABLE ONLY opcao_mpc.cliente DROP CONSTRAINT cliente_pkey;
ALTER TABLE ONLY opcao_mpc.caixa DROP CONSTRAINT caixa_pkey;
ALTER TABLE opcao_mpc.venda ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.subproduto ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.produtoestoque ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.produto ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.itemvenda ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.gastogenerico ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.funcionario ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.fornecedor ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.compra ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.comissao ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.cliente ALTER COLUMN codigo DROP DEFAULT;
ALTER TABLE opcao_mpc.caixa ALTER COLUMN codigo DROP DEFAULT;
DROP SEQUENCE opcao_mpc.venda_codigo_seq;
DROP TABLE opcao_mpc.venda;
DROP TABLE opcao_mpc.super_usuario;
DROP SEQUENCE opcao_mpc.subproduto_codigo_seq;
DROP TABLE opcao_mpc.subproduto;
DROP SEQUENCE opcao_mpc.produtoestoque_codigo_seq;
DROP TABLE opcao_mpc.produtoestoque;
DROP SEQUENCE opcao_mpc.produto_codigo_seq;
DROP TABLE opcao_mpc.produto;
DROP TABLE opcao_mpc.log;
DROP SEQUENCE opcao_mpc.itemvenda_codigo_seq;
DROP TABLE opcao_mpc.itemvenda;
DROP SEQUENCE opcao_mpc.gastogenerico_codigo_seq;
DROP TABLE opcao_mpc.gastogenerico;
DROP SEQUENCE opcao_mpc.funcionario_codigo_seq;
DROP TABLE opcao_mpc.funcionario;
DROP SEQUENCE opcao_mpc.fornecedor_codigo_seq;
DROP TABLE opcao_mpc.fornecedor;
DROP SEQUENCE opcao_mpc.compra_codigo_seq;
DROP TABLE opcao_mpc.compra;
DROP SEQUENCE opcao_mpc.comissao_codigo_seq;
DROP TABLE opcao_mpc.comissao;
DROP SEQUENCE opcao_mpc.cliente_codigo_seq;
DROP TABLE opcao_mpc.cliente;
DROP SEQUENCE opcao_mpc.caixa_codigo_seq;
DROP TABLE opcao_mpc.caixa;
DROP FUNCTION opcao_mpc.limpa_string(texto character varying);
DROP EXTENSION plpgsql;
DROP SCHEMA opcao_mpc;
--
-- Name: opcao_mpc; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA opcao_mpc;


ALTER SCHEMA opcao_mpc OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = opcao_mpc, pg_catalog;

--
-- Name: limpa_string(character varying); Type: FUNCTION; Schema: opcao_mpc; Owner: postgres
--

CREATE FUNCTION limpa_string(texto character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
Select translate(
  $1, 
  'áàâãäåaaaÁÂÃÄÅAAAÀéèêëeeeeeEEEÉEEÈìíîïìiiiÌÍÎÏÌIIIóôõöoooòÒÓÔÕÖOOOùúûüuuuuÙÚÛÜUUUUçÇñÑýÝ', 
  'aaaaaaaaaAAAAAAAAAeeeeeeeeeEEEEEEEiiiiiiiiIIIIIIIIooooooooOOOOOOOOuuuuuuuuUUUUUUUUcCnNyY'
);  
$_$;


ALTER FUNCTION opcao_mpc.limpa_string(texto character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: caixa; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE caixa (
    codigo bigint NOT NULL,
    valor_em_caixa real NOT NULL,
    data date NOT NULL
);


ALTER TABLE caixa OWNER TO postgres;

--
-- Name: caixa_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE caixa_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE caixa_codigo_seq OWNER TO postgres;

--
-- Name: caixa_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE caixa_codigo_seq OWNED BY caixa.codigo;


--
-- Name: cliente; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE cliente (
    codigo bigint NOT NULL,
    nome character varying(100) NOT NULL,
    telefone_1 character varying(25),
    telefone_2 character varying(25),
    endereco character varying(200),
    cep integer,
    numero integer,
    cidade character varying(100)
);


ALTER TABLE cliente OWNER TO postgres;

--
-- Name: cliente_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE cliente_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cliente_codigo_seq OWNER TO postgres;

--
-- Name: cliente_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE cliente_codigo_seq OWNED BY cliente.codigo;


--
-- Name: comissao; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE comissao (
    codigo bigint NOT NULL,
    codigo_funcionario bigint NOT NULL,
    valor real NOT NULL,
    data date NOT NULL
);


ALTER TABLE comissao OWNER TO postgres;

--
-- Name: comissao_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE comissao_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE comissao_codigo_seq OWNER TO postgres;

--
-- Name: comissao_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE comissao_codigo_seq OWNED BY comissao.codigo;


--
-- Name: compra; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE compra (
    codigo bigint NOT NULL,
    codigo_produtoestoque bigint NOT NULL,
    quantidade real NOT NULL,
    valor_pago real NOT NULL,
    data date NOT NULL
);


ALTER TABLE compra OWNER TO postgres;

--
-- Name: compra_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE compra_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE compra_codigo_seq OWNER TO postgres;

--
-- Name: compra_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE compra_codigo_seq OWNED BY compra.codigo;


--
-- Name: fornecedor; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE fornecedor (
    codigo bigint NOT NULL,
    nome character varying(100) NOT NULL,
    nome_fantasia character varying(100),
    cnpj character varying(20),
    telefone_1 character varying(25),
    telefone_2 character varying(25),
    telefone_3 character varying(25),
    endereco character varying(200),
    cep integer,
    numero integer,
    cidade character varying(100),
    estado character varying(100)
);


ALTER TABLE fornecedor OWNER TO postgres;

--
-- Name: fornecedor_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE fornecedor_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE fornecedor_codigo_seq OWNER TO postgres;

--
-- Name: fornecedor_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE fornecedor_codigo_seq OWNED BY fornecedor.codigo;


--
-- Name: funcionario; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE funcionario (
    codigo bigint NOT NULL,
    nome character varying(100) NOT NULL,
    usuario character varying(50) NOT NULL,
    senha character varying(100) NOT NULL,
    comissionado boolean DEFAULT false NOT NULL,
    funcao character varying(50),
    salario real,
    ultimo_pagamento date
);


ALTER TABLE funcionario OWNER TO postgres;

--
-- Name: funcionario_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE funcionario_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE funcionario_codigo_seq OWNER TO postgres;

--
-- Name: funcionario_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE funcionario_codigo_seq OWNED BY funcionario.codigo;


--
-- Name: gastogenerico; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE gastogenerico (
    codigo bigint NOT NULL,
    nome character varying(30) NOT NULL,
    valor real NOT NULL,
    descricao character varying(200) NOT NULL,
    data date NOT NULL
);


ALTER TABLE gastogenerico OWNER TO postgres;

--
-- Name: gastogenerico_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE gastogenerico_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gastogenerico_codigo_seq OWNER TO postgres;

--
-- Name: gastogenerico_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE gastogenerico_codigo_seq OWNED BY gastogenerico.codigo;


--
-- Name: itemvenda; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE itemvenda (
    codigo bigint NOT NULL,
    codigo_produto bigint NOT NULL,
    codigo_subproduto bigint NOT NULL,
    codigo_venda bigint NOT NULL,
    quantidade real NOT NULL,
    subtotal real NOT NULL
);


ALTER TABLE itemvenda OWNER TO postgres;

--
-- Name: itemvenda_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE itemvenda_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE itemvenda_codigo_seq OWNER TO postgres;

--
-- Name: itemvenda_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE itemvenda_codigo_seq OWNED BY itemvenda.codigo;


--
-- Name: log; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE log (
    data timestamp with time zone DEFAULT now() NOT NULL,
    usuario bigint NOT NULL,
    tabela character varying(20) NOT NULL,
    acao character varying(10) NOT NULL,
    codigo_executado character varying(500) NOT NULL
);


ALTER TABLE log OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE produto (
    codigo bigint NOT NULL,
    nome character varying(100) NOT NULL,
    localizacao character varying(200),
    limite_minimo integer,
    caminho_imagem character varying(200),
    ativo boolean DEFAULT true NOT NULL
);


ALTER TABLE produto OWNER TO postgres;

--
-- Name: produto_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE produto_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produto_codigo_seq OWNER TO postgres;

--
-- Name: produto_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE produto_codigo_seq OWNED BY produto.codigo;


--
-- Name: produtoestoque; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE produtoestoque (
    codigo bigint NOT NULL,
    codigo_produto bigint NOT NULL,
    codigo_fornecedor bigint NOT NULL,
    preco real NOT NULL,
    data_adicao date NOT NULL,
    preco_venda real NOT NULL,
    quantidade_estoque real NOT NULL
);


ALTER TABLE produtoestoque OWNER TO postgres;

--
-- Name: produtoestoque_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE produtoestoque_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produtoestoque_codigo_seq OWNER TO postgres;

--
-- Name: produtoestoque_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE produtoestoque_codigo_seq OWNED BY produtoestoque.codigo;


--
-- Name: subproduto; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE subproduto (
    codigo bigint NOT NULL,
    nome character varying(100) NOT NULL,
    codigo_produto bigint NOT NULL,
    fracao real NOT NULL,
    caminho_imagem character varying(200),
    ativo boolean DEFAULT true NOT NULL
);


ALTER TABLE subproduto OWNER TO postgres;

--
-- Name: subproduto_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE subproduto_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE subproduto_codigo_seq OWNER TO postgres;

--
-- Name: subproduto_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE subproduto_codigo_seq OWNED BY subproduto.codigo;


--
-- Name: super_usuario; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE super_usuario (
    codigo smallint NOT NULL,
    senha character varying(100) NOT NULL
);


ALTER TABLE super_usuario OWNER TO postgres;

--
-- Name: venda; Type: TABLE; Schema: opcao_mpc; Owner: postgres
--

CREATE TABLE venda (
    codigo bigint NOT NULL,
    codigo_funcionario bigint NOT NULL,
    codigo_cliente bigint NOT NULL,
    codigo_comissao bigint,
    desconto real,
    frete real,
    valor_cobrado real NOT NULL,
    forma_pagamento character varying(20),
    cancelada boolean DEFAULT false NOT NULL,
    data date NOT NULL,
    nome_funcionario character varying(100) NOT NULL,
    nome_cliente character varying(100) NOT NULL
);


ALTER TABLE venda OWNER TO postgres;

--
-- Name: venda_codigo_seq; Type: SEQUENCE; Schema: opcao_mpc; Owner: postgres
--

CREATE SEQUENCE venda_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE venda_codigo_seq OWNER TO postgres;

--
-- Name: venda_codigo_seq; Type: SEQUENCE OWNED BY; Schema: opcao_mpc; Owner: postgres
--

ALTER SEQUENCE venda_codigo_seq OWNED BY venda.codigo;


--
-- Name: caixa codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY caixa ALTER COLUMN codigo SET DEFAULT nextval('caixa_codigo_seq'::regclass);


--
-- Name: cliente codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY cliente ALTER COLUMN codigo SET DEFAULT nextval('cliente_codigo_seq'::regclass);


--
-- Name: comissao codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY comissao ALTER COLUMN codigo SET DEFAULT nextval('comissao_codigo_seq'::regclass);


--
-- Name: compra codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY compra ALTER COLUMN codigo SET DEFAULT nextval('compra_codigo_seq'::regclass);


--
-- Name: fornecedor codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY fornecedor ALTER COLUMN codigo SET DEFAULT nextval('fornecedor_codigo_seq'::regclass);


--
-- Name: funcionario codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY funcionario ALTER COLUMN codigo SET DEFAULT nextval('funcionario_codigo_seq'::regclass);


--
-- Name: gastogenerico codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY gastogenerico ALTER COLUMN codigo SET DEFAULT nextval('gastogenerico_codigo_seq'::regclass);


--
-- Name: itemvenda codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY itemvenda ALTER COLUMN codigo SET DEFAULT nextval('itemvenda_codigo_seq'::regclass);


--
-- Name: produto codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produto ALTER COLUMN codigo SET DEFAULT nextval('produto_codigo_seq'::regclass);


--
-- Name: produtoestoque codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produtoestoque ALTER COLUMN codigo SET DEFAULT nextval('produtoestoque_codigo_seq'::regclass);


--
-- Name: subproduto codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY subproduto ALTER COLUMN codigo SET DEFAULT nextval('subproduto_codigo_seq'::regclass);


--
-- Name: venda codigo; Type: DEFAULT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY venda ALTER COLUMN codigo SET DEFAULT nextval('venda_codigo_seq'::regclass);


--
-- Data for Name: caixa; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY caixa (codigo, valor_em_caixa, data) FROM stdin;
\.
COPY caixa (codigo, valor_em_caixa, data) FROM '$$PATH$$/2276.dat';

--
-- Name: caixa_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('caixa_codigo_seq', 50, true);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY cliente (codigo, nome, telefone_1, telefone_2, endereco, cep, numero, cidade) FROM stdin;
\.
COPY cliente (codigo, nome, telefone_1, telefone_2, endereco, cep, numero, cidade) FROM '$$PATH$$/2270.dat';

--
-- Name: cliente_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('cliente_codigo_seq', 1, false);


--
-- Data for Name: comissao; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY comissao (codigo, codigo_funcionario, valor, data) FROM stdin;
\.
COPY comissao (codigo, codigo_funcionario, valor, data) FROM '$$PATH$$/2268.dat';

--
-- Name: comissao_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('comissao_codigo_seq', 1, false);


--
-- Data for Name: compra; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY compra (codigo, codigo_produtoestoque, quantidade, valor_pago, data) FROM stdin;
\.
COPY compra (codigo, codigo_produtoestoque, quantidade, valor_pago, data) FROM '$$PATH$$/2272.dat';

--
-- Name: compra_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('compra_codigo_seq', 1, false);


--
-- Data for Name: fornecedor; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY fornecedor (codigo, nome, nome_fantasia, cnpj, telefone_1, telefone_2, telefone_3, endereco, cep, numero, cidade, estado) FROM stdin;
\.
COPY fornecedor (codigo, nome, nome_fantasia, cnpj, telefone_1, telefone_2, telefone_3, endereco, cep, numero, cidade, estado) FROM '$$PATH$$/2256.dat';

--
-- Name: fornecedor_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('fornecedor_codigo_seq', 1, false);


--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY funcionario (codigo, nome, usuario, senha, comissionado, funcao, salario, ultimo_pagamento) FROM stdin;
\.
COPY funcionario (codigo, nome, usuario, senha, comissionado, funcao, salario, ultimo_pagamento) FROM '$$PATH$$/2262.dat';

--
-- Name: funcionario_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('funcionario_codigo_seq', 11, true);


--
-- Data for Name: gastogenerico; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY gastogenerico (codigo, nome, valor, descricao, data) FROM stdin;
\.
COPY gastogenerico (codigo, nome, valor, descricao, data) FROM '$$PATH$$/2274.dat';

--
-- Name: gastogenerico_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('gastogenerico_codigo_seq', 1, false);


--
-- Data for Name: itemvenda; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY itemvenda (codigo, codigo_produto, codigo_subproduto, codigo_venda, quantidade, subtotal) FROM stdin;
\.
COPY itemvenda (codigo, codigo_produto, codigo_subproduto, codigo_venda, quantidade, subtotal) FROM '$$PATH$$/2266.dat';

--
-- Name: itemvenda_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('itemvenda_codigo_seq', 1, false);


--
-- Data for Name: log; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY log (data, usuario, tabela, acao, codigo_executado) FROM stdin;
\.
COPY log (data, usuario, tabela, acao, codigo_executado) FROM '$$PATH$$/2277.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY produto (codigo, nome, localizacao, limite_minimo, caminho_imagem, ativo) FROM stdin;
\.
COPY produto (codigo, nome, localizacao, limite_minimo, caminho_imagem, ativo) FROM '$$PATH$$/2254.dat';

--
-- Name: produto_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('produto_codigo_seq', 1, true);


--
-- Data for Name: produtoestoque; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY produtoestoque (codigo, codigo_produto, codigo_fornecedor, preco, data_adicao, preco_venda, quantidade_estoque) FROM stdin;
\.
COPY produtoestoque (codigo, codigo_produto, codigo_fornecedor, preco, data_adicao, preco_venda, quantidade_estoque) FROM '$$PATH$$/2260.dat';

--
-- Name: produtoestoque_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('produtoestoque_codigo_seq', 1, false);


--
-- Data for Name: subproduto; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY subproduto (codigo, nome, codigo_produto, fracao, caminho_imagem, ativo) FROM stdin;
\.
COPY subproduto (codigo, nome, codigo_produto, fracao, caminho_imagem, ativo) FROM '$$PATH$$/2258.dat';

--
-- Name: subproduto_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('subproduto_codigo_seq', 1, false);


--
-- Data for Name: super_usuario; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY super_usuario (codigo, senha) FROM stdin;
\.
COPY super_usuario (codigo, senha) FROM '$$PATH$$/2278.dat';

--
-- Data for Name: venda; Type: TABLE DATA; Schema: opcao_mpc; Owner: postgres
--

COPY venda (codigo, codigo_funcionario, codigo_cliente, codigo_comissao, desconto, frete, valor_cobrado, forma_pagamento, cancelada, data, nome_funcionario, nome_cliente) FROM stdin;
\.
COPY venda (codigo, codigo_funcionario, codigo_cliente, codigo_comissao, desconto, frete, valor_cobrado, forma_pagamento, cancelada, data, nome_funcionario, nome_cliente) FROM '$$PATH$$/2264.dat';

--
-- Name: venda_codigo_seq; Type: SEQUENCE SET; Schema: opcao_mpc; Owner: postgres
--

SELECT pg_catalog.setval('venda_codigo_seq', 1, false);


--
-- Name: caixa caixa_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY caixa
    ADD CONSTRAINT caixa_pkey PRIMARY KEY (codigo);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (codigo);


--
-- Name: comissao comissao_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY comissao
    ADD CONSTRAINT comissao_pkey PRIMARY KEY (codigo);


--
-- Name: compra compra_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT compra_pkey PRIMARY KEY (codigo);


--
-- Name: fornecedor fornecedor_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY fornecedor
    ADD CONSTRAINT fornecedor_pkey PRIMARY KEY (codigo);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (codigo);


--
-- Name: gastogenerico gastogenerico_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY gastogenerico
    ADD CONSTRAINT gastogenerico_pkey PRIMARY KEY (codigo);


--
-- Name: itemvenda itemvenda_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY itemvenda
    ADD CONSTRAINT itemvenda_pkey PRIMARY KEY (codigo);


--
-- Name: log log_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY log
    ADD CONSTRAINT log_pkey PRIMARY KEY (data, usuario, tabela, acao);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (codigo);


--
-- Name: produtoestoque produtoestoque_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produtoestoque
    ADD CONSTRAINT produtoestoque_pkey PRIMARY KEY (codigo);


--
-- Name: subproduto subproduto_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY subproduto
    ADD CONSTRAINT subproduto_pkey PRIMARY KEY (codigo);


--
-- Name: super_usuario super_usuario_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY super_usuario
    ADD CONSTRAINT super_usuario_pkey PRIMARY KEY (codigo);


--
-- Name: venda venda_pkey; Type: CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY venda
    ADD CONSTRAINT venda_pkey PRIMARY KEY (codigo);


--
-- Name: ix_usuario; Type: INDEX; Schema: opcao_mpc; Owner: postgres
--

CREATE INDEX ix_usuario ON funcionario USING btree (usuario varchar_pattern_ops);


--
-- Name: comissao comissao_codigo_funcionario_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY comissao
    ADD CONSTRAINT comissao_codigo_funcionario_fkey FOREIGN KEY (codigo_funcionario) REFERENCES funcionario(codigo);


--
-- Name: compra compra_codigo_produtoestoque_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT compra_codigo_produtoestoque_fkey FOREIGN KEY (codigo_produtoestoque) REFERENCES produtoestoque(codigo);


--
-- Name: itemvenda itemvenda_codigo_produto_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY itemvenda
    ADD CONSTRAINT itemvenda_codigo_produto_fkey FOREIGN KEY (codigo_produto) REFERENCES produto(codigo);


--
-- Name: itemvenda itemvenda_codigo_subproduto_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY itemvenda
    ADD CONSTRAINT itemvenda_codigo_subproduto_fkey FOREIGN KEY (codigo_subproduto) REFERENCES subproduto(codigo);


--
-- Name: itemvenda itemvenda_codigo_venda_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY itemvenda
    ADD CONSTRAINT itemvenda_codigo_venda_fkey FOREIGN KEY (codigo_venda) REFERENCES venda(codigo);


--
-- Name: produtoestoque produtoestoque_codigo_fornecedor_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produtoestoque
    ADD CONSTRAINT produtoestoque_codigo_fornecedor_fkey FOREIGN KEY (codigo_fornecedor) REFERENCES fornecedor(codigo);


--
-- Name: produtoestoque produtoestoque_codigo_produto_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY produtoestoque
    ADD CONSTRAINT produtoestoque_codigo_produto_fkey FOREIGN KEY (codigo_produto) REFERENCES produto(codigo);


--
-- Name: subproduto subproduto_codigo_produto_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY subproduto
    ADD CONSTRAINT subproduto_codigo_produto_fkey FOREIGN KEY (codigo_produto) REFERENCES produto(codigo);


--
-- Name: venda venda_codigo_cliente_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY venda
    ADD CONSTRAINT venda_codigo_cliente_fkey FOREIGN KEY (codigo_cliente) REFERENCES cliente(codigo);


--
-- Name: venda venda_codigo_comissao_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY venda
    ADD CONSTRAINT venda_codigo_comissao_fkey FOREIGN KEY (codigo_comissao) REFERENCES comissao(codigo);


--
-- Name: venda venda_codigo_funcionario_fkey; Type: FK CONSTRAINT; Schema: opcao_mpc; Owner: postgres
--

ALTER TABLE ONLY venda
    ADD CONSTRAINT venda_codigo_funcionario_fkey FOREIGN KEY (codigo_funcionario) REFERENCES funcionario(codigo);


--
-- Name: caixa; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE caixa FROM postgres;


--
-- Name: caixa_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE caixa_codigo_seq FROM postgres;


--
-- Name: cliente; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE cliente FROM postgres;


--
-- Name: cliente_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE cliente_codigo_seq FROM postgres;


--
-- Name: comissao; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE comissao FROM postgres;


--
-- Name: comissao_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE comissao_codigo_seq FROM postgres;


--
-- Name: compra; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE compra FROM postgres;


--
-- Name: compra_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE compra_codigo_seq FROM postgres;


--
-- Name: fornecedor; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE fornecedor FROM postgres;


--
-- Name: fornecedor_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE fornecedor_codigo_seq FROM postgres;


--
-- Name: funcionario; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE funcionario FROM postgres;


--
-- Name: funcionario_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE funcionario_codigo_seq FROM postgres;


--
-- Name: gastogenerico; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE gastogenerico FROM postgres;


--
-- Name: gastogenerico_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE gastogenerico_codigo_seq FROM postgres;


--
-- Name: itemvenda; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE itemvenda FROM postgres;


--
-- Name: itemvenda_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE itemvenda_codigo_seq FROM postgres;


--
-- Name: produto; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE produto FROM postgres;


--
-- Name: produto_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE produto_codigo_seq FROM postgres;


--
-- Name: produtoestoque; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE produtoestoque FROM postgres;


--
-- Name: produtoestoque_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE produtoestoque_codigo_seq FROM postgres;


--
-- Name: subproduto; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE subproduto FROM postgres;


--
-- Name: subproduto_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE subproduto_codigo_seq FROM postgres;


--
-- Name: venda; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON TABLE venda FROM postgres;


--
-- Name: venda_codigo_seq; Type: ACL; Schema: opcao_mpc; Owner: postgres
--

REVOKE ALL ON SEQUENCE venda_codigo_seq FROM postgres;


--
-- PostgreSQL database dump complete
--

